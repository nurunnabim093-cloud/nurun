import { useState } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { TooltipProvider } from "@/components/ui/tooltip";
import QRGenerator from "@/pages/QRGenerator";
import BatchGenerator from "@/pages/BatchGenerator";
import QRScanner from "@/pages/QRScanner";
import VCardGenerator from "@/pages/VCardGenerator";
import WiFiGenerator from "@/pages/WiFiGenerator";

const queryClient = new QueryClient();

type Tab = "single" | "batch" | "vcard" | "wifi" | "scan";

interface TabDef {
  id: Tab;
  label: string;
  shortLabel: string;
  accent: string;
  icon: React.ReactNode;
}

const TABS: TabDef[] = [
  {
    id: "single",
    label: "QR কোড",
    shortLabel: "QR",
    accent: "bg-sky-500 shadow-sky-500/25",
    icon: (
      <svg className="w-4 h-4 flex-shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
        <rect x="3" y="3" width="7" height="7" rx="1" />
        <rect x="14" y="3" width="7" height="7" rx="1" />
        <rect x="3" y="14" width="7" height="7" rx="1" />
        <rect x="14" y="14" width="3" height="3" rx="0.5" />
      </svg>
    ),
  },
  {
    id: "batch",
    label: "ব্যাচ",
    shortLabel: "ব্যাচ",
    accent: "bg-sky-500 shadow-sky-500/25",
    icon: (
      <svg className="w-4 h-4 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
        <path strokeLinecap="round" strokeLinejoin="round" d="M4 6h16M4 10h16M4 14h16M4 18h16" />
      </svg>
    ),
  },
  {
    id: "vcard",
    label: "কন্টাক্ট",
    shortLabel: "কার্ড",
    accent: "bg-violet-500 shadow-violet-500/25",
    icon: (
      <svg className="w-4 h-4 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
        <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 6a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0zM4.501 20.118a7.5 7.5 0 0114.998 0A17.933 17.933 0 0112 21.75c-2.676 0-5.216-.584-7.499-1.632z" />
      </svg>
    ),
  },
  {
    id: "wifi",
    label: "WiFi",
    shortLabel: "WiFi",
    accent: "bg-emerald-500 shadow-emerald-500/25",
    icon: (
      <svg className="w-4 h-4 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
        <path strokeLinecap="round" strokeLinejoin="round" d="M8.288 15.038a5.25 5.25 0 017.424 0M5.106 11.856c3.807-3.808 9.98-3.808 13.788 0M1.924 8.674c5.565-5.565 14.587-5.565 20.152 0M12.53 18.22l-.53.53-.53-.53a.75.75 0 011.06 0z" />
      </svg>
    ),
  },
  {
    id: "scan",
    label: "স্ক্যান",
    shortLabel: "স্ক্যান",
    accent: "bg-sky-500 shadow-sky-500/25",
    icon: (
      <svg className="w-4 h-4 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
        <path strokeLinecap="round" strokeLinejoin="round" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
      </svg>
    ),
  },
];

function AppShell() {
  const [tab, setTab] = useState<Tab>("single");
  const activeAccent = TABS.find((t) => t.id === tab)?.accent ?? "bg-sky-500 shadow-sky-500/25";

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white flex flex-col items-center py-10 px-4">
      {/* Header */}
      <div className="mb-6 text-center">
        <div className="flex items-center justify-center gap-3 mb-2">
          <div className="w-10 h-10 rounded-xl bg-sky-500 flex items-center justify-center shadow-lg shadow-sky-500/30">
            <svg className="w-6 h-6 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <rect x="3" y="3" width="7" height="7" rx="1" />
              <rect x="14" y="3" width="7" height="7" rx="1" />
              <rect x="3" y="14" width="7" height="7" rx="1" />
              <rect x="14" y="14" width="3" height="3" rx="0.5" />
              <rect x="19" y="14" width="2" height="2" rx="0.5" />
              <rect x="14" y="19" width="2" height="2" rx="0.5" />
              <rect x="18" y="18" width="3" height="3" rx="0.5" />
            </svg>
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-white">
            নুরুন্নবী বারকোড জেনারেটর প্রো
          </h1>
        </div>
        <p className="text-slate-400 text-sm">যেকোনো টেক্সট বা URL থেকে QR কোড তৈরি করুন</p>
      </div>

      {/* Tab switcher */}
      <div className="w-full max-w-2xl mb-5">
        <div className="flex gap-1 bg-slate-800/80 border border-slate-700/50 rounded-2xl p-1">
          {TABS.map(({ id, label, shortLabel, accent, icon }) => (
            <button
              key={id}
              onClick={() => setTab(id)}
              className={`flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all ${
                tab === id
                  ? `${accent} text-white shadow-lg`
                  : "text-slate-400 hover:text-white"
              }`}
            >
              {icon}
              <span className="hidden sm:inline">{label}</span>
              <span className="sm:hidden">{shortLabel}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Page content */}
      <div className="w-full max-w-2xl">
        {tab === "single" && <QRGenerator headless />}
        {tab === "batch" && <BatchGenerator />}
        {tab === "vcard" && <VCardGenerator />}
        {tab === "wifi" && <WiFiGenerator />}
        {tab === "scan" && <QRScanner />}
      </div>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <AppShell />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
