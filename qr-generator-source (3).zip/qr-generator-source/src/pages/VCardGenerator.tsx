import { useState, useCallback } from "react";
import QRCode from "qrcode";
import { printQR } from "@/utils/printQR";

interface VCardFields {
  firstName: string;
  lastName: string;
  phone: string;
  mobile: string;
  email: string;
  organization: string;
  title: string;
  website: string;
  street: string;
  city: string;
  country: string;
}

const EMPTY: VCardFields = {
  firstName: "",
  lastName: "",
  phone: "",
  mobile: "",
  email: "",
  organization: "",
  title: "",
  website: "",
  street: "",
  city: "",
  country: "",
};

function buildVCard(f: VCardFields): string {
  const lines: string[] = ["BEGIN:VCARD", "VERSION:3.0"];
  const fullName = [f.firstName.trim(), f.lastName.trim()].filter(Boolean).join(" ");
  if (fullName) {
    lines.push(`FN:${fullName}`);
    lines.push(`N:${f.lastName.trim()};${f.firstName.trim()};;;`);
  }
  if (f.organization.trim()) lines.push(`ORG:${f.organization.trim()}`);
  if (f.title.trim()) lines.push(`TITLE:${f.title.trim()}`);
  if (f.phone.trim()) lines.push(`TEL;TYPE=WORK,VOICE:${f.phone.trim()}`);
  if (f.mobile.trim()) lines.push(`TEL;TYPE=CELL:${f.mobile.trim()}`);
  if (f.email.trim()) lines.push(`EMAIL:${f.email.trim()}`);
  if (f.website.trim()) {
    const url = f.website.trim().startsWith("http") ? f.website.trim() : `https://${f.website.trim()}`;
    lines.push(`URL:${url}`);
  }
  const hasAddr = f.street.trim() || f.city.trim() || f.country.trim();
  if (hasAddr) {
    lines.push(`ADR;TYPE=WORK:;;${f.street.trim()};${f.city.trim()};;;${f.country.trim()}`);
  }
  lines.push("END:VCARD");
  return lines.join("\n");
}

function hasContent(f: VCardFields): boolean {
  return Object.values(f).some((v) => v.trim() !== "");
}

function InputField({
  label,
  placeholder,
  value,
  onChange,
  type = "text",
  icon,
}: {
  label: string;
  placeholder: string;
  value: string;
  onChange: (v: string) => void;
  type?: string;
  icon: React.ReactNode;
}) {
  return (
    <div>
      <label className="block text-xs text-slate-400 mb-1.5">{label}</label>
      <div className="flex items-center gap-2.5 bg-slate-900/80 border border-slate-600 rounded-xl px-3 py-2.5 focus-within:border-violet-500 focus-within:ring-1 focus-within:ring-violet-500/40 transition">
        <span className="text-slate-500 flex-shrink-0">{icon}</span>
        <input
          type={type}
          placeholder={placeholder}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="flex-1 bg-transparent text-white text-sm placeholder-slate-500 focus:outline-none"
        />
      </div>
    </div>
  );
}

export default function VCardGenerator() {
  const [fields, setFields] = useState<VCardFields>(EMPTY);
  const [qrDataUrl, setQrDataUrl] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState("");
  const [size] = useState(300);
  const [copied, setCopied] = useState(false);

  const set = (key: keyof VCardFields) => (val: string) =>
    setFields((prev) => ({ ...prev, [key]: val }));

  const generate = useCallback(async () => {
    if (!hasContent(fields)) {
      setError("অন্তত একটি ফিল্ড পূরণ করুন।");
      return;
    }
    setError("");
    setIsGenerating(true);
    try {
      const vcard = buildVCard(fields);
      const url = await QRCode.toDataURL(vcard, {
        width: size,
        margin: 2,
        errorCorrectionLevel: "M",
        color: { dark: "#000000", light: "#ffffff" },
      });
      setQrDataUrl(url);
    } catch {
      setError("QR কোড তৈরি করা সম্ভব হয়নি।");
    } finally {
      setIsGenerating(false);
    }
  }, [fields, size]);

  const download = useCallback(() => {
    if (!qrDataUrl) return;
    const name = [fields.firstName, fields.lastName].filter(Boolean).join("_") || "contact";
    const a = document.createElement("a");
    a.href = qrDataUrl;
    a.download = `vcard_${name}.png`;
    a.click();
  }, [qrDataUrl, fields]);

  const handlePrint = useCallback(() => {
    if (!qrDataUrl) return;
    const fullName = [fields.firstName, fields.lastName].filter(Boolean).join(" ") || "Contact";
    const sub = [fields.title, fields.organization].filter(Boolean).join(" · ");
    printQR({ dataUrl: qrDataUrl, label: fullName, sublabel: sub || undefined, size });
  }, [qrDataUrl, fields, size]);

  const copyVCard = useCallback(async () => {
    if (!hasContent(fields)) return;
    try {
      await navigator.clipboard.writeText(buildVCard(fields));
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch { /* ignore */ }
  }, [fields]);

  const reset = useCallback(() => {
    setFields(EMPTY);
    setQrDataUrl("");
    setError("");
  }, []);

  const previewName = [fields.firstName, fields.lastName].filter(Boolean).join(" ") || "নাম নেই";

  return (
    <div className="w-full max-w-2xl mx-auto space-y-4">
      {/* Preview chip */}
      <div className="flex items-center gap-3 bg-slate-800/60 border border-slate-700/50 rounded-2xl px-5 py-4 shadow-xl">
        <div className="w-12 h-12 rounded-xl bg-violet-500/20 flex items-center justify-center flex-shrink-0 border border-violet-500/30">
          <svg className="w-6 h-6 text-violet-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 6a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0zM4.501 20.118a7.5 7.5 0 0114.998 0A17.933 17.933 0 0112 21.75c-2.676 0-5.216-.584-7.499-1.632z" />
          </svg>
        </div>
        <div className="min-w-0">
          <p className="text-white font-semibold truncate">{previewName}</p>
          <p className="text-xs text-slate-400 mt-0.5 truncate">
            {[fields.title, fields.organization].filter(Boolean).join(" · ") || "পদবী / প্রতিষ্ঠান"}
          </p>
        </div>
        <button
          onClick={reset}
          className="ml-auto p-2 rounded-lg text-slate-500 hover:text-red-400 hover:bg-red-500/10 transition flex-shrink-0"
          title="রিসেট করুন"
        >
          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
          </svg>
        </button>
      </div>

      {/* Name section */}
      <div className="bg-slate-800/60 backdrop-blur border border-slate-700/50 rounded-2xl p-5 shadow-xl space-y-3">
        <h2 className="text-xs font-semibold text-violet-400 uppercase tracking-wider flex items-center gap-2">
          <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 6a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0z" />
          </svg>
          ব্যক্তিগত তথ্য
        </h2>
        <div className="grid grid-cols-2 gap-3">
          <InputField label="নাম (প্রথম)" placeholder="যেমন: নুরুন্নবী" value={fields.firstName} onChange={set("firstName")}
            icon={<svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M15.75 6a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0z" /></svg>}
          />
          <InputField label="নাম (শেষ)" placeholder="যেমন: আহমেদ" value={fields.lastName} onChange={set("lastName")}
            icon={<svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M15.75 6a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0z" /></svg>}
          />
        </div>
        <InputField label="পদবী (Title)" placeholder="যেমন: ম্যানেজার, CEO" value={fields.title} onChange={set("title")}
          icon={<svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>}
        />
        <InputField label="প্রতিষ্ঠান" placeholder="যেমন: ABC Company" value={fields.organization} onChange={set("organization")}
          icon={<svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M3.75 21h16.5M4.5 3h15M5.25 3v18m13.5-18v18M9 6.75h1.5m-1.5 3h1.5m-1.5 3h1.5m3-6H15m-1.5 3H15m-1.5 3H15M9 21v-3.375c0-.621.504-1.125 1.125-1.125h3.75c.621 0 1.125.504 1.125 1.125V21" /></svg>}
        />
      </div>

      {/* Contact section */}
      <div className="bg-slate-800/60 backdrop-blur border border-slate-700/50 rounded-2xl p-5 shadow-xl space-y-3">
        <h2 className="text-xs font-semibold text-violet-400 uppercase tracking-wider flex items-center gap-2">
          <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 6.75c0 8.284 6.716 15 15 15h2.25a2.25 2.25 0 002.25-2.25v-1.372c0-.516-.351-.966-.852-1.091l-4.423-1.106c-.44-.11-.902.055-1.173.417l-.97 1.293c-.282.376-.769.542-1.21.38a12.035 12.035 0 01-7.143-7.143c-.162-.441.004-.928.38-1.21l1.293-.97c.363-.271.527-.734.417-1.173L6.963 3.102a1.125 1.125 0 00-1.091-.852H4.5A2.25 2.25 0 002.25 4.5v2.25z" />
          </svg>
          যোগাযোগ
        </h2>
        <InputField label="মোবাইল নম্বর" placeholder="যেমন: +8801XXXXXXXXX" value={fields.mobile} onChange={set("mobile")} type="tel"
          icon={<svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M10.5 1.5H8.25A2.25 2.25 0 006 3.75v16.5a2.25 2.25 0 002.25 2.25h7.5A2.25 2.25 0 0018 20.25V3.75a2.25 2.25 0 00-2.25-2.25H13.5m-3 0V3h3V1.5m-3 0h3m-3 8.25h3" /></svg>}
        />
        <InputField label="অফিস ফোন" placeholder="যেমন: +88029XXXXXXX" value={fields.phone} onChange={set("phone")} type="tel"
          icon={<svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M2.25 6.75c0 8.284 6.716 15 15 15h2.25a2.25 2.25 0 002.25-2.25v-1.372c0-.516-.351-.966-.852-1.091l-4.423-1.106c-.44-.11-.902.055-1.173.417l-.97 1.293c-.282.376-.769.542-1.21.38a12.035 12.035 0 01-7.143-7.143c-.162-.441.004-.928.38-1.21l1.293-.97c.363-.271.527-.734.417-1.173L6.963 3.102a1.125 1.125 0 00-1.091-.852H4.5A2.25 2.25 0 002.25 4.5v2.25z" /></svg>}
        />
        <InputField label="ইমেইল" placeholder="example@email.com" value={fields.email} onChange={set("email")} type="email"
          icon={<svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M21.75 6.75v10.5a2.25 2.25 0 01-2.25 2.25h-15a2.25 2.25 0 01-2.25-2.25V6.75m19.5 0A2.25 2.25 0 0019.5 4.5h-15a2.25 2.25 0 00-2.25 2.25m19.5 0v.243a2.25 2.25 0 01-1.07 1.916l-7.5 4.615a2.25 2.25 0 01-2.36 0L3.32 8.91a2.25 2.25 0 01-1.07-1.916V6.75" /></svg>}
        />
        <InputField label="ওয়েবসাইট" placeholder="www.example.com" value={fields.website} onChange={set("website")} type="url"
          icon={<svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M12 21a9.004 9.004 0 008.716-6.747M12 21a9.004 9.004 0 01-8.716-6.747M12 21c2.485 0 4.5-4.03 4.5-9S14.485 3 12 3m0 18c-2.485 0-4.5-4.03-4.5-9S9.515 3 12 3m0 0a8.997 8.997 0 017.843 4.582M12 3a8.997 8.997 0 00-7.843 4.582m15.686 0A11.953 11.953 0 0112 10.5c-2.998 0-5.74-1.1-7.843-2.918m15.686 0A8.959 8.959 0 0121 12c0 .778-.099 1.533-.284 2.253" /></svg>}
        />
      </div>

      {/* Address section */}
      <div className="bg-slate-800/60 backdrop-blur border border-slate-700/50 rounded-2xl p-5 shadow-xl space-y-3">
        <h2 className="text-xs font-semibold text-violet-400 uppercase tracking-wider flex items-center gap-2">
          <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M15 10.5a3 3 0 11-6 0 3 3 0 016 0z" />
            <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1115 0z" />
          </svg>
          ঠিকানা
        </h2>
        <InputField label="রাস্তা / এলাকা" placeholder="যেমন: ১২৩, মিরপুর রোড" value={fields.street} onChange={set("street")}
          icon={<svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M2.25 12l8.954-8.955c.44-.439 1.152-.439 1.591 0L21.75 12M4.5 9.75v10.125c0 .621.504 1.125 1.125 1.125H9.75v-4.875c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125V21h4.125c.621 0 1.125-.504 1.125-1.125V9.75M8.25 21h8.25" /></svg>}
        />
        <div className="grid grid-cols-2 gap-3">
          <InputField label="শহর" placeholder="যেমন: ঢাকা" value={fields.city} onChange={set("city")}
            icon={<svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M15 10.5a3 3 0 11-6 0 3 3 0 016 0z" /><path strokeLinecap="round" strokeLinejoin="round" d="M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1115 0z" /></svg>}
          />
          <InputField label="দেশ" placeholder="যেমন: Bangladesh" value={fields.country} onChange={set("country")}
            icon={<svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M12 21a9.004 9.004 0 008.716-6.747M12 21a9.004 9.004 0 01-8.716-6.747M12 21c2.485 0 4.5-4.03 4.5-9S14.485 3 12 3m0 18c-2.485 0-4.5-4.03-4.5-9S9.515 3 12 3" /></svg>}
          />
        </div>
      </div>

      {/* Error */}
      {error && (
        <p className="text-sm text-red-400 flex items-center gap-1.5">
          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.538-1.333-3.308 0L3.732 16c-.77 1.333.192 3 1.732 3z" />
          </svg>
          {error}
        </p>
      )}

      {/* Generate button */}
      <button
        onClick={generate}
        disabled={isGenerating}
        className="w-full py-4 bg-violet-500 hover:bg-violet-400 disabled:opacity-50 disabled:cursor-not-allowed text-white font-semibold rounded-2xl shadow-lg shadow-violet-500/30 transition-all active:scale-95 text-base"
      >
        {isGenerating ? (
          <span className="flex items-center justify-center gap-2">
            <svg className="w-5 h-5 animate-spin" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
            </svg>
            তৈরি হচ্ছে...
          </span>
        ) : (
          <span className="flex items-center justify-center gap-2">
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 6a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0zM4.501 20.118a7.5 7.5 0 0114.998 0A17.933 17.933 0 0112 21.75c-2.676 0-5.216-.584-7.499-1.632z" />
            </svg>
            কন্টাক্ট QR কোড তৈরি করুন
          </span>
        )}
      </button>

      {/* QR Output */}
      {qrDataUrl && (
        <div className="bg-slate-800/60 backdrop-blur border border-slate-700/50 rounded-2xl p-6 shadow-xl flex flex-col items-center gap-5">
          {/* Contact summary */}
          <div className="w-full flex items-center gap-3 pb-4 border-b border-slate-700/40">
            <div className="w-10 h-10 rounded-xl bg-violet-500/20 flex items-center justify-center flex-shrink-0 border border-violet-500/30">
              <svg className="w-5 h-5 text-violet-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 6a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0zM4.501 20.118a7.5 7.5 0 0114.998 0" />
              </svg>
            </div>
            <div className="min-w-0">
              <p className="text-white font-semibold text-sm truncate">{previewName}</p>
              <p className="text-xs text-slate-400 truncate">{[fields.title, fields.organization].filter(Boolean).join(" · ")}</p>
            </div>
            <span className="ml-auto text-xs bg-violet-500/20 text-violet-300 border border-violet-500/30 px-2 py-0.5 rounded-full">vCard 3.0</span>
          </div>

          <div className="rounded-xl overflow-hidden shadow-2xl border border-slate-600/30">
            <img src={qrDataUrl} alt="vCard QR Code" style={{ width: size, height: size, display: "block" }} />
          </div>

          <p className="text-xs text-slate-500 text-center">
            যেকোনো স্মার্টফোনের ক্যামেরা বা কন্টাক্ট অ্যাপ দিয়ে স্ক্যান করুন
          </p>

          <div className="flex gap-3 w-full">
            <button
              onClick={download}
              className="flex-1 flex items-center justify-center gap-2 py-3 bg-emerald-500 hover:bg-emerald-400 text-white font-semibold rounded-xl shadow-lg shadow-emerald-500/25 transition-all active:scale-95"
            >
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
              </svg>
              ডাউনলোড করুন
            </button>
            <button
              onClick={handlePrint}
              className="px-5 py-3 font-medium rounded-xl transition-all active:scale-95 border bg-slate-700 hover:bg-slate-600 text-slate-200 border-slate-600"
              title="প্রিন্ট করুন"
            >
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M6.72 13.829c-.24.03-.48.062-.72.096m.72-.096a42.415 42.415 0 0110.56 0m-10.56 0L6.34 18m10.94-4.171c.24.03.48.062.72.096m-.72-.096L17.66 18m0 0l.229 2.523a1.125 1.125 0 01-1.12 1.227H7.231c-.662 0-1.18-.568-1.12-1.227L6.34 18m11.318 0h1.091A2.25 2.25 0 0021 15.75V9.456c0-1.081-.768-2.015-1.837-2.175a48.055 48.055 0 00-1.913-.247M6.34 18H5.25A2.25 2.25 0 013 15.75V9.456c0-1.081.768-2.015 1.837-2.175a48.041 48.041 0 011.913-.247m10.5 0a48.536 48.536 0 00-10.5 0m10.5 0V3.375c0-.621-.504-1.125-1.125-1.125h-8.25c-.621 0-1.125.504-1.125 1.125v3.659M18 10.5h.008v.008H18V10.5zm-3 0h.008v.008H15V10.5z" />
              </svg>
            </button>
            <button
              onClick={copyVCard}
              className={`px-5 py-3 font-medium rounded-xl transition-all active:scale-95 border text-sm ${
                copied
                  ? "bg-violet-500/20 border-violet-500 text-violet-300"
                  : "bg-slate-700 hover:bg-slate-600 text-slate-200 border-slate-600"
              }`}
              title="vCard টেক্সট কপি করুন"
            >
              {copied ? (
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>
              ) : (
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" /></svg>
              )}
            </button>
          </div>
        </div>
      )}

      <p className="text-center text-xs text-slate-500 pb-4">
        vCard 3.0 ফরম্যাট — Android, iPhone ও সব স্মার্টফোনে সাপোর্টেড
      </p>
    </div>
  );
}
