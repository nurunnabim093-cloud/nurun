import { useState, useCallback } from "react";
import QRCode from "qrcode";
import { printQR } from "@/utils/printQR";

type SecurityType = "WPA" | "WEP" | "nopass";

function buildWiFiString(ssid: string, password: string, security: SecurityType, hidden: boolean): string {
  const esc = (s: string) => s.replace(/([\\;,":=])/g, "\\$1");
  if (security === "nopass") {
    return `WIFI:T:nopass;S:${esc(ssid)};P:;;H:${hidden ? "true" : "false"};;`;
  }
  return `WIFI:T:${security};S:${esc(ssid)};P:${esc(password)};;H:${hidden ? "true" : "false"};;`;
}

export default function WiFiGenerator() {
  const [ssid, setSsid] = useState("");
  const [password, setPassword] = useState("");
  const [security, setSecurity] = useState<SecurityType>("WPA");
  const [hidden, setHidden] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [size] = useState(300);

  const [qrDataUrl, setQrDataUrl] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState("");
  const [copied, setCopied] = useState(false);

  const generate = useCallback(async () => {
    if (!ssid.trim()) {
      setError("নেটওয়ার্কের নাম (SSID) দিন।");
      return;
    }
    if (security !== "nopass" && !password.trim()) {
      setError("পাসওয়ার্ড দিন অথবা 'পাসওয়ার্ড নেই' নির্বাচন করুন।");
      return;
    }
    setError("");
    setIsGenerating(true);
    try {
      const wifiStr = buildWiFiString(ssid.trim(), password, security, hidden);
      const url = await QRCode.toDataURL(wifiStr, {
        width: size,
        margin: 2,
        errorCorrectionLevel: "M",
        color: { dark: "#000000", light: "#ffffff" },
      });
      setQrDataUrl(url);
    } catch {
      setError("QR কোড তৈরি করা সম্ভব হয়নি।");
    } finally {
      setIsGenerating(false);
    }
  }, [ssid, password, security, hidden, size]);

  const download = useCallback(() => {
    if (!qrDataUrl) return;
    const a = document.createElement("a");
    a.href = qrDataUrl;
    a.download = `wifi_${ssid.replace(/\s+/g, "_") || "network"}.png`;
    a.click();
  }, [qrDataUrl, ssid]);

  const handlePrint = useCallback(() => {
    if (!qrDataUrl) return;
    printQR({
      dataUrl: qrDataUrl,
      label: ssid || "WiFi Network",
      sublabel: security === "nopass" ? "Open Network" : `${security} Secured${hidden ? " · Hidden" : ""}`,
      size,
    });
  }, [qrDataUrl, ssid, security, hidden, size]);

  const copyString = useCallback(async () => {
    if (!ssid.trim()) return;
    try {
      await navigator.clipboard.writeText(buildWiFiString(ssid.trim(), password, security, hidden));
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch { /* ignore */ }
  }, [ssid, password, security, hidden]);

  return (
    <div className="w-full max-w-2xl mx-auto space-y-4">
      {/* Network card preview */}
      <div className="bg-slate-800/60 backdrop-blur border border-slate-700/50 rounded-2xl px-5 py-4 shadow-xl flex items-center gap-4">
        <div className="w-12 h-12 rounded-xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center flex-shrink-0">
          <svg className="w-6 h-6 text-emerald-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M8.288 15.038a5.25 5.25 0 017.424 0M5.106 11.856c3.807-3.808 9.98-3.808 13.788 0M1.924 8.674c5.565-5.565 14.587-5.565 20.152 0M12.53 18.22l-.53.53-.53-.53a.75.75 0 011.06 0z" />
          </svg>
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-white font-semibold truncate">{ssid || "নেটওয়ার্কের নাম"}</p>
          <div className="flex items-center gap-2 mt-0.5">
            <span className={`text-xs px-1.5 py-0.5 rounded-full font-medium ${
              security === "nopass"
                ? "bg-slate-600/60 text-slate-400"
                : "bg-emerald-500/20 text-emerald-400"
            }`}>
              {security === "nopass" ? "Open" : security}
            </span>
            {hidden && <span className="text-xs bg-amber-500/20 text-amber-400 px-1.5 py-0.5 rounded-full">Hidden</span>}
          </div>
        </div>
        {qrDataUrl && (
          <button
            onClick={() => { setQrDataUrl(""); setError(""); }}
            className="p-2 rounded-lg text-slate-500 hover:text-red-400 hover:bg-red-500/10 transition flex-shrink-0"
            title="রিসেট"
          >
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
            </svg>
          </button>
        )}
      </div>

      {/* Settings card */}
      <div className="bg-slate-800/60 backdrop-blur border border-slate-700/50 rounded-2xl p-6 shadow-xl space-y-4">
        <h2 className="text-xs font-semibold text-emerald-400 uppercase tracking-wider flex items-center gap-2">
          <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M8.288 15.038a5.25 5.25 0 017.424 0M5.106 11.856c3.807-3.808 9.98-3.808 13.788 0M1.924 8.674c5.565-5.565 14.587-5.565 20.152 0M12.53 18.22l-.53.53-.53-.53a.75.75 0 011.06 0z" />
          </svg>
          নেটওয়ার্ক সেটিংস
        </h2>

        {/* SSID */}
        <div>
          <label className="block text-xs text-slate-400 mb-1.5">নেটওয়ার্কের নাম (SSID) *</label>
          <div className="flex items-center gap-2.5 bg-slate-900/80 border border-slate-600 rounded-xl px-3 py-2.5 focus-within:border-emerald-500 focus-within:ring-1 focus-within:ring-emerald-500/40 transition">
            <svg className="w-4 h-4 text-slate-500 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M8.288 15.038a5.25 5.25 0 017.424 0M5.106 11.856c3.807-3.808 9.98-3.808 13.788 0M1.924 8.674c5.565-5.565 14.587-5.565 20.152 0M12.53 18.22l-.53.53-.53-.53a.75.75 0 011.06 0z" />
            </svg>
            <input
              type="text"
              placeholder="যেমন: MyHomeNetwork"
              value={ssid}
              onChange={(e) => setSsid(e.target.value)}
              className="flex-1 bg-transparent text-white text-sm placeholder-slate-500 focus:outline-none"
            />
          </div>
        </div>

        {/* Security type */}
        <div>
          <label className="block text-xs text-slate-400 mb-1.5">নিরাপত্তা ধরন</label>
          <div className="flex gap-2">
            {(["WPA", "WEP", "nopass"] as SecurityType[]).map((s) => (
              <button
                key={s}
                onClick={() => setSecurity(s)}
                className={`flex-1 py-2 rounded-xl text-sm font-medium border transition-all ${
                  security === s
                    ? "bg-emerald-500 border-emerald-500 text-white shadow-lg shadow-emerald-500/20"
                    : "bg-slate-900/80 border-slate-600 text-slate-300 hover:border-emerald-500/40"
                }`}
              >
                {s === "nopass" ? "Open" : s}
              </button>
            ))}
          </div>
        </div>

        {/* Password */}
        {security !== "nopass" && (
          <div>
            <label className="block text-xs text-slate-400 mb-1.5">পাসওয়ার্ড *</label>
            <div className="flex items-center gap-2.5 bg-slate-900/80 border border-slate-600 rounded-xl px-3 py-2.5 focus-within:border-emerald-500 focus-within:ring-1 focus-within:ring-emerald-500/40 transition">
              <svg className="w-4 h-4 text-slate-500 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M16.5 10.5V6.75a4.5 4.5 0 10-9 0v3.75m-.75 11.25h10.5a2.25 2.25 0 002.25-2.25v-6.75a2.25 2.25 0 00-2.25-2.25H6.75a2.25 2.25 0 00-2.25 2.25v6.75a2.25 2.25 0 002.25 2.25z" />
              </svg>
              <input
                type={showPassword ? "text" : "password"}
                placeholder="WiFi পাসওয়ার্ড"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="flex-1 bg-transparent text-white text-sm placeholder-slate-500 focus:outline-none"
              />
              <button
                type="button"
                onClick={() => setShowPassword((v) => !v)}
                className="text-slate-500 hover:text-slate-300 transition flex-shrink-0"
              >
                {showPassword ? (
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M3.98 8.223A10.477 10.477 0 001.934 12C3.226 16.338 7.244 19.5 12 19.5c.993 0 1.953-.138 2.863-.395M6.228 6.228A10.45 10.45 0 0112 4.5c4.756 0 8.773 3.162 10.065 7.498a10.523 10.523 0 01-4.293 5.774M6.228 6.228L3 3m3.228 3.228l3.65 3.65m7.894 7.894L21 21m-3.228-3.228l-3.65-3.65m0 0a3 3 0 10-4.243-4.243m4.242 4.242L9.88 9.88" />
                  </svg>
                ) : (
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M2.036 12.322a1.012 1.012 0 010-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178z" />
                    <path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                  </svg>
                )}
              </button>
            </div>
          </div>
        )}

        {/* Hidden network toggle */}
        <label className="flex items-center gap-3 cursor-pointer group">
          <div
            onClick={() => setHidden((v) => !v)}
            className={`w-10 h-6 rounded-full transition-colors flex-shrink-0 flex items-center px-0.5 ${hidden ? "bg-emerald-500" : "bg-slate-600"}`}
          >
            <span className={`w-5 h-5 rounded-full bg-white shadow transition-transform ${hidden ? "translate-x-4" : "translate-x-0"}`} />
          </div>
          <div>
            <p className="text-sm text-slate-300 group-hover:text-white transition">হিডেন নেটওয়ার্ক</p>
            <p className="text-xs text-slate-500">নেটওয়ার্কটি লুকানো থাকলে এটি চালু রাখুন</p>
          </div>
        </label>
      </div>

      {/* Error */}
      {error && (
        <p className="text-sm text-red-400 flex items-center gap-1.5">
          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.538-1.333-3.308 0L3.732 16c-.77 1.333.192 3 1.732 3z" />
          </svg>
          {error}
        </p>
      )}

      {/* Generate button */}
      <button
        onClick={generate}
        disabled={isGenerating}
        className="w-full py-4 bg-emerald-500 hover:bg-emerald-400 disabled:opacity-50 disabled:cursor-not-allowed text-white font-semibold rounded-2xl shadow-lg shadow-emerald-500/30 transition-all active:scale-95 text-base"
      >
        {isGenerating ? (
          <span className="flex items-center justify-center gap-2">
            <svg className="w-5 h-5 animate-spin" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
            </svg>
            তৈরি হচ্ছে...
          </span>
        ) : (
          <span className="flex items-center justify-center gap-2">
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M8.288 15.038a5.25 5.25 0 017.424 0M5.106 11.856c3.807-3.808 9.98-3.808 13.788 0M1.924 8.674c5.565-5.565 14.587-5.565 20.152 0M12.53 18.22l-.53.53-.53-.53a.75.75 0 011.06 0z" />
            </svg>
            WiFi QR কোড তৈরি করুন
          </span>
        )}
      </button>

      {/* QR Output */}
      {qrDataUrl && (
        <div className="bg-slate-800/60 backdrop-blur border border-slate-700/50 rounded-2xl p-6 shadow-xl flex flex-col items-center gap-5">
          {/* Network summary */}
          <div className="w-full flex items-center gap-3 pb-4 border-b border-slate-700/40">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/20 flex items-center justify-center flex-shrink-0 border border-emerald-500/30">
              <svg className="w-4 h-4 text-emerald-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M8.288 15.038a5.25 5.25 0 017.424 0M5.106 11.856c3.807-3.808 9.98-3.808 13.788 0M1.924 8.674c5.565-5.565 14.587-5.565 20.152 0M12.53 18.22l-.53.53-.53-.53a.75.75 0 011.06 0z" />
              </svg>
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-white font-semibold text-sm truncate">{ssid}</p>
              <p className="text-xs text-slate-400">{security === "nopass" ? "Open network" : `${security} secured`}{hidden ? " · Hidden" : ""}</p>
            </div>
            <span className="text-xs bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-2 py-0.5 rounded-full">WiFi</span>
          </div>

          <div className="rounded-xl overflow-hidden shadow-2xl border border-slate-600/30">
            <img src={qrDataUrl} alt="WiFi QR Code" style={{ width: size, height: size, display: "block" }} />
          </div>

          <p className="text-xs text-slate-500 text-center">
            ক্যামেরা দিয়ে স্ক্যান করুন — পাসওয়ার্ড না টাইপ করেই কানেক্ট হবে
          </p>

          <div className="flex gap-3 w-full">
            <button
              onClick={download}
              className="flex-1 flex items-center justify-center gap-2 py-3 bg-emerald-500 hover:bg-emerald-400 text-white font-semibold rounded-xl shadow-lg shadow-emerald-500/25 transition-all active:scale-95"
            >
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
              </svg>
              ডাউনলোড করুন
            </button>
            <button
              onClick={handlePrint}
              className="px-5 py-3 font-medium rounded-xl transition-all active:scale-95 border bg-slate-700 hover:bg-slate-600 text-slate-200 border-slate-600"
              title="প্রিন্ট করুন"
            >
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M6.72 13.829c-.24.03-.48.062-.72.096m.72-.096a42.415 42.415 0 0110.56 0m-10.56 0L6.34 18m10.94-4.171c.24.03.48.062.72.096m-.72-.096L17.66 18m0 0l.229 2.523a1.125 1.125 0 01-1.12 1.227H7.231c-.662 0-1.18-.568-1.12-1.227L6.34 18m11.318 0h1.091A2.25 2.25 0 0021 15.75V9.456c0-1.081-.768-2.015-1.837-2.175a48.055 48.055 0 00-1.913-.247M6.34 18H5.25A2.25 2.25 0 013 15.75V9.456c0-1.081.768-2.015 1.837-2.175a48.041 48.041 0 011.913-.247m10.5 0a48.536 48.536 0 00-10.5 0m10.5 0V3.375c0-.621-.504-1.125-1.125-1.125h-8.25c-.621 0-1.125.504-1.125 1.125v3.659M18 10.5h.008v.008H18V10.5zm-3 0h.008v.008H15V10.5z" />
              </svg>
            </button>
            <button
              onClick={copyString}
              className={`px-5 py-3 font-medium rounded-xl transition-all active:scale-95 border ${
                copied
                  ? "bg-emerald-500/20 border-emerald-500 text-emerald-300"
                  : "bg-slate-700 hover:bg-slate-600 text-slate-200 border-slate-600"
              }`}
              title="WiFi স্ট্রিং কপি"
            >
              {copied ? (
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>
              ) : (
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" /></svg>
              )}
            </button>
          </div>
        </div>
      )}

      {/* Tip */}
      <div className="bg-amber-500/10 border border-amber-500/20 rounded-xl px-4 py-3 flex gap-3">
        <svg className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126zM12 15.75h.007v.008H12v-.008z" />
        </svg>
        <p className="text-xs text-amber-300/80 leading-relaxed">
          QR কোডে পাসওয়ার্ড সংরক্ষিত থাকে। শুধুমাত্র বিশ্বস্ত মানুষের সাথে শেয়ার করুন।
        </p>
      </div>

      <p className="text-center text-xs text-slate-500 pb-4">
        Android ও iOS — উভয় ডিভাইসে ক্যামেরা দিয়ে সরাসরি কানেক্ট হওয়া যাবে
      </p>
    </div>
  );
}
