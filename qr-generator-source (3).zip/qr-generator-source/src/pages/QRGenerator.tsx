import { useState, useRef, useCallback } from "react";
import QRCode from "qrcode";
import { useQRHistory, type HistoryEntry } from "@/hooks/useQRHistory";
import { printQR } from "@/utils/printQR";

type ErrorLevel = "L" | "M" | "Q" | "H";
type OutputFormat = "png" | "svg";
type OverlayType = "none" | "image" | "text";

function formatTime(ts: number): string {
  const d = new Date(ts);
  const now = new Date();
  const diffMs = now.getTime() - d.getTime();
  const diffMin = Math.floor(diffMs / 60000);
  if (diffMin < 1) return "এইমাত্র";
  if (diffMin < 60) return `${diffMin} মিনিট আগে`;
  const diffHr = Math.floor(diffMin / 60);
  if (diffHr < 24) return `${diffHr} ঘণ্টা আগে`;
  const diffDay = Math.floor(diffHr / 24);
  return `${diffDay} দিন আগে`;
}

async function applyCaption(qrDataUrl: string, caption: string, captionColor: string, bgColor: string): Promise<string> {
  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => {
      const padding = Math.round(img.width * 0.04);
      const fontSize = Math.max(Math.round(img.width * 0.055), 13);
      const stripH = fontSize + padding * 2.4;
      const canvas = document.createElement("canvas");
      canvas.width = img.width;
      canvas.height = img.height + stripH;
      const ctx = canvas.getContext("2d")!;

      // Fill background for the caption strip using the QR bg color
      ctx.fillStyle = bgColor;
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(img, 0, 0);

      // Caption text
      ctx.font = `600 ${fontSize}px Arial, sans-serif`;
      ctx.fillStyle = captionColor;
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText(caption, canvas.width / 2, img.height + stripH / 2, canvas.width - padding * 2);
      resolve(canvas.toDataURL("image/png"));
    };
    img.src = qrDataUrl;
  });
}

async function applyOverlay(
  qrDataUrl: string,
  overlay: { type: OverlayType; imageDataUrl?: string; text?: string; textColor?: string }
): Promise<string> {
  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement("canvas");
      canvas.width = img.width;
      canvas.height = img.height;
      const ctx = canvas.getContext("2d")!;
      ctx.drawImage(img, 0, 0);

      const cx = canvas.width / 2;
      const cy = canvas.height / 2;

      if (overlay.type === "image" && overlay.imageDataUrl) {
        const logoImg = new Image();
        logoImg.onload = () => {
          // Logo occupies ~22% of QR size for H-level error correction safety
          const logoSize = canvas.width * 0.22;
          const padding = logoSize * 0.18;
          const bgSize = logoSize + padding * 2;

          // White rounded background
          ctx.save();
          ctx.fillStyle = "#ffffff";
          const r = bgSize * 0.15;
          ctx.beginPath();
          ctx.moveTo(cx - bgSize / 2 + r, cy - bgSize / 2);
          ctx.lineTo(cx + bgSize / 2 - r, cy - bgSize / 2);
          ctx.arcTo(cx + bgSize / 2, cy - bgSize / 2, cx + bgSize / 2, cy - bgSize / 2 + r, r);
          ctx.lineTo(cx + bgSize / 2, cy + bgSize / 2 - r);
          ctx.arcTo(cx + bgSize / 2, cy + bgSize / 2, cx + bgSize / 2 - r, cy + bgSize / 2, r);
          ctx.lineTo(cx - bgSize / 2 + r, cy + bgSize / 2);
          ctx.arcTo(cx - bgSize / 2, cy + bgSize / 2, cx - bgSize / 2, cy + bgSize / 2 - r, r);
          ctx.lineTo(cx - bgSize / 2, cy - bgSize / 2 + r);
          ctx.arcTo(cx - bgSize / 2, cy - bgSize / 2, cx - bgSize / 2 + r, cy - bgSize / 2, r);
          ctx.closePath();
          ctx.fill();
          ctx.restore();

          // Draw logo, centered, preserving aspect ratio
          const aspect = logoImg.width / logoImg.height;
          let lw = logoSize;
          let lh = logoSize;
          if (aspect > 1) lh = logoSize / aspect;
          else lw = logoSize * aspect;

          ctx.drawImage(logoImg, cx - lw / 2, cy - lh / 2, lw, lh);
          resolve(canvas.toDataURL("image/png"));
        };
        logoImg.src = overlay.imageDataUrl;
      } else if (overlay.type === "text" && overlay.text) {
        const fontSize = Math.max(canvas.width * 0.065, 12);
        ctx.font = `bold ${fontSize}px Arial, sans-serif`;
        const measured = ctx.measureText(overlay.text);
        const tw = measured.width;
        const th = fontSize;
        const ph = th * 0.45;
        const pw = th * 0.6;
        const bgW = tw + pw * 2;
        const bgH = th + ph * 2;
        const r = bgH * 0.25;

        ctx.save();
        ctx.fillStyle = "#ffffff";
        ctx.beginPath();
        ctx.moveTo(cx - bgW / 2 + r, cy - bgH / 2);
        ctx.lineTo(cx + bgW / 2 - r, cy - bgH / 2);
        ctx.arcTo(cx + bgW / 2, cy - bgH / 2, cx + bgW / 2, cy - bgH / 2 + r, r);
        ctx.lineTo(cx + bgW / 2, cy + bgH / 2 - r);
        ctx.arcTo(cx + bgW / 2, cy + bgH / 2, cx + bgW / 2 - r, cy + bgH / 2, r);
        ctx.lineTo(cx - bgW / 2 + r, cy + bgH / 2);
        ctx.arcTo(cx - bgW / 2, cy + bgH / 2, cx - bgW / 2, cy + bgH / 2 - r, r);
        ctx.lineTo(cx - bgW / 2, cy - bgH / 2 + r);
        ctx.arcTo(cx - bgW / 2, cy - bgH / 2, cx - bgW / 2 + r, cy - bgH / 2, r);
        ctx.closePath();
        ctx.fill();
        ctx.restore();

        ctx.font = `bold ${fontSize}px Arial, sans-serif`;
        ctx.fillStyle = overlay.textColor ?? "#000000";
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillText(overlay.text, cx, cy);

        resolve(canvas.toDataURL("image/png"));
      } else {
        resolve(canvas.toDataURL("image/png"));
      }
    };
    img.src = qrDataUrl;
  });
}

function HistoryCard({
  entry,
  onReuse,
  onDownload,
  onRemove,
}: {
  entry: HistoryEntry;
  onReuse: (e: HistoryEntry) => void;
  onDownload: (e: HistoryEntry) => void;
  onRemove: (id: string) => void;
}) {
  return (
    <div className="flex items-center gap-3 bg-slate-900/70 border border-slate-700/50 rounded-xl p-3 group">
      <div
        className="w-14 h-14 rounded-lg overflow-hidden flex-shrink-0 border border-slate-600/40 cursor-pointer"
        onClick={() => onReuse(entry)}
        title="পুনরায় লোড করুন"
      >
        <img src={entry.dataUrl} alt="QR" className="w-full h-full object-cover" />
      </div>
      <div className="flex-1 min-w-0 cursor-pointer" onClick={() => onReuse(entry)}>
        <p className="text-sm text-white font-medium truncate">{entry.text}</p>
        <p className="text-xs text-slate-500 mt-0.5">
          {entry.size}px · {entry.format.toUpperCase()} · {formatTime(entry.createdAt)}
        </p>
        <div className="flex items-center gap-1.5 mt-1">
          <span className="w-3 h-3 rounded-full border border-slate-600 inline-block" style={{ background: entry.fgColor }} />
          <span className="w-3 h-3 rounded-full border border-slate-600 inline-block" style={{ background: entry.bgColor }} />
        </div>
      </div>
      <div className="flex flex-col gap-1.5 opacity-0 group-hover:opacity-100 transition-opacity">
        <button
          onClick={() => onDownload(entry)}
          className="p-1.5 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/40 text-emerald-400 transition"
          title="ডাউনলোড করুন"
        >
          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
          </svg>
        </button>
        <button
          onClick={() => onRemove(entry.id)}
          className="p-1.5 rounded-lg bg-red-500/20 hover:bg-red-500/40 text-red-400 transition"
          title="মুছুন"
        >
          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>
      </div>
    </div>
  );
}

export default function QRGenerator({ headless = false }: { headless?: boolean }) {
  const [input, setInput] = useState("");
  const [fgColor, setFgColor] = useState("#000000");
  const [bgColor, setBgColor] = useState("#ffffff");
  const [size, setSize] = useState(300);
  const [errorLevel, setErrorLevel] = useState<ErrorLevel>("H");
  const [outputFormat, setOutputFormat] = useState<OutputFormat>("png");

  // Overlay state
  const [overlayType, setOverlayType] = useState<OverlayType>("none");
  const [overlayImageDataUrl, setOverlayImageDataUrl] = useState<string>("");
  const [overlayImageName, setOverlayImageName] = useState<string>("");
  const [overlayText, setOverlayText] = useState("");
  const [overlayTextColor, setOverlayTextColor] = useState("#000000");

  // Caption state
  const [caption, setCaption] = useState("");
  const [captionColor, setCaptionColor] = useState("#000000");

  const [qrDataUrl, setQrDataUrl] = useState<string>("");
  const [qrSvg, setQrSvg] = useState<string>("");
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState<string>("");
  const [copied, setCopied] = useState(false);
  const [showHistory, setShowHistory] = useState(true);

  const logoInputRef = useRef<HTMLInputElement>(null);
  const { history, addEntry, removeEntry, clearAll } = useQRHistory();

  const handleLogoUpload = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      setOverlayImageDataUrl(ev.target?.result as string);
      setOverlayImageName(file.name);
    };
    reader.readAsDataURL(file);
  }, []);

  const generate = useCallback(async () => {
    const text = input.trim();
    if (!text) {
      setError("কিছু লিখুন অথবা একটি URL দিন।");
      return;
    }
    if (overlayType !== "none" && outputFormat === "svg") {
      setError("লোগো/ওয়াটারমার্ক শুধুমাত্র PNG ফরম্যাটে সাপোর্ট করে।");
      return;
    }
    setError("");
    setIsGenerating(true);
    try {
      // Always use H error correction when overlay is active for scannability
      const effectiveLevel: ErrorLevel = overlayType !== "none" ? "H" : errorLevel;

      const thumbUrl = await QRCode.toDataURL(text, {
        width: 128,
        margin: 1,
        color: { dark: fgColor, light: bgColor },
        errorCorrectionLevel: effectiveLevel,
      });

      if (outputFormat === "png") {
        const rawUrl = await QRCode.toDataURL(text, {
          width: size,
          margin: 2,
          color: { dark: fgColor, light: bgColor },
          errorCorrectionLevel: effectiveLevel,
        });

        let finalUrl = rawUrl;
        if (overlayType === "image" && overlayImageDataUrl) {
          finalUrl = await applyOverlay(rawUrl, { type: "image", imageDataUrl: overlayImageDataUrl });
        } else if (overlayType === "text" && overlayText.trim()) {
          finalUrl = await applyOverlay(rawUrl, { type: "text", text: overlayText.trim(), textColor: overlayTextColor });
        }
        if (caption.trim()) {
          finalUrl = await applyCaption(finalUrl, caption.trim(), captionColor, bgColor);
        }

        setQrDataUrl(finalUrl);
        setQrSvg("");
        addEntry({ text, dataUrl: thumbUrl, fgColor, bgColor, size, errorLevel: effectiveLevel, format: "png" });
      } else {
        const svg = await QRCode.toString(text, {
          type: "svg",
          width: size,
          margin: 2,
          color: { dark: fgColor, light: bgColor },
          errorCorrectionLevel: effectiveLevel,
        });
        setQrSvg(svg);
        setQrDataUrl("");
        addEntry({ text, dataUrl: thumbUrl, fgColor, bgColor, size, errorLevel: effectiveLevel, format: "svg" });
      }
    } catch {
      setError("QR কোড তৈরি করা সম্ভব হয়নি। আবার চেষ্টা করুন।");
    } finally {
      setIsGenerating(false);
    }
  }, [input, fgColor, bgColor, size, errorLevel, outputFormat, overlayType, overlayImageDataUrl, overlayText, overlayTextColor, caption, captionColor, addEntry]);

  const download = useCallback((dataUrl?: string, svg?: string, fmt?: OutputFormat) => {
    const f = fmt ?? outputFormat;
    const d = dataUrl ?? qrDataUrl;
    const s = svg ?? qrSvg;
    if (f === "png" && d) {
      const a = document.createElement("a");
      a.href = d;
      a.download = "qrcode.png";
      a.click();
    } else if (f === "svg" && s) {
      const blob = new Blob([s], { type: "image/svg+xml" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "qrcode.svg";
      a.click();
      URL.revokeObjectURL(url);
    }
  }, [outputFormat, qrDataUrl, qrSvg]);

  const downloadHistoryEntry = useCallback(async (entry: HistoryEntry) => {
    if (entry.format === "png") {
      const url = await QRCode.toDataURL(entry.text, {
        width: entry.size,
        margin: 2,
        color: { dark: entry.fgColor, light: entry.bgColor },
        errorCorrectionLevel: entry.errorLevel as ErrorLevel,
      });
      const a = document.createElement("a");
      a.href = url;
      a.download = "qrcode.png";
      a.click();
    } else {
      const svg = await QRCode.toString(entry.text, {
        type: "svg",
        width: entry.size,
        margin: 2,
        color: { dark: entry.fgColor, light: entry.bgColor },
        errorCorrectionLevel: entry.errorLevel as ErrorLevel,
      });
      const blob = new Blob([svg], { type: "image/svg+xml" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "qrcode.svg";
      a.click();
      URL.revokeObjectURL(url);
    }
  }, []);

  const reuseEntry = useCallback(async (entry: HistoryEntry) => {
    setInput(entry.text);
    setFgColor(entry.fgColor);
    setBgColor(entry.bgColor);
    setSize(entry.size);
    setErrorLevel(entry.errorLevel as ErrorLevel);
    setOutputFormat(entry.format);
    setError("");
    setIsGenerating(true);
    try {
      if (entry.format === "png") {
        const url = await QRCode.toDataURL(entry.text, {
          width: entry.size, margin: 2,
          color: { dark: entry.fgColor, light: entry.bgColor },
          errorCorrectionLevel: entry.errorLevel as ErrorLevel,
        });
        setQrDataUrl(url);
        setQrSvg("");
      } else {
        const svg = await QRCode.toString(entry.text, {
          type: "svg", width: entry.size, margin: 2,
          color: { dark: entry.fgColor, light: entry.bgColor },
          errorCorrectionLevel: entry.errorLevel as ErrorLevel,
        });
        setQrSvg(svg);
        setQrDataUrl("");
      }
    } catch { /* ignore */ } finally {
      setIsGenerating(false);
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  }, []);

  const copyText = useCallback(async () => {
    try {
      await navigator.clipboard.writeText(input);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch { /* ignore */ }
  }, [input]);

  const handlePrint = useCallback(() => {
    if (!qrDataUrl) return;
    printQR({ dataUrl: qrDataUrl, label: input, sublabel: caption.trim() || undefined, size });
  }, [qrDataUrl, input, caption, size]);

  const hasQR = outputFormat === "png" ? !!qrDataUrl : !!qrSvg;

  const inner = (
    <div className="w-full max-w-2xl space-y-4">
        {/* Input Card */}
        <div className="bg-slate-800/60 backdrop-blur border border-slate-700/50 rounded-2xl p-6 shadow-xl">
          <label className="block text-sm font-medium text-slate-300 mb-2">
            টেক্সট / নাম / URL
          </label>
          <textarea
            className="w-full bg-slate-900/80 border border-slate-600 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-sky-500/60 focus:border-sky-500 resize-none transition"
            rows={3}
            placeholder="এখানে টেক্সট, নাম অথবা URL লিখুন..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => { if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) generate(); }}
          />
          {error && (
            <p className="mt-2 text-sm text-red-400 flex items-center gap-1">
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.538-1.333-3.308 0L3.732 16c-.77 1.333.192 3 1.732 3z" />
              </svg>
              {error}
            </p>
          )}
        </div>

        {/* Settings Card */}
        <div className="bg-slate-800/60 backdrop-blur border border-slate-700/50 rounded-2xl p-6 shadow-xl">
          <h2 className="text-sm font-semibold text-slate-300 mb-4 uppercase tracking-wider">কাস্টমাইজ করুন</h2>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs text-slate-400 mb-1.5">QR কোড রঙ</label>
              <div className="flex items-center gap-2 bg-slate-900/80 border border-slate-600 rounded-xl px-3 py-2">
                <input type="color" value={fgColor} onChange={(e) => setFgColor(e.target.value)} className="w-8 h-8 rounded-lg cursor-pointer border-0 bg-transparent" />
                <span className="text-sm text-slate-300 font-mono">{fgColor.toUpperCase()}</span>
              </div>
            </div>
            <div>
              <label className="block text-xs text-slate-400 mb-1.5">ব্যাকগ্রাউন্ড রঙ</label>
              <div className="flex items-center gap-2 bg-slate-900/80 border border-slate-600 rounded-xl px-3 py-2">
                <input type="color" value={bgColor} onChange={(e) => setBgColor(e.target.value)} className="w-8 h-8 rounded-lg cursor-pointer border-0 bg-transparent" />
                <span className="text-sm text-slate-300 font-mono">{bgColor.toUpperCase()}</span>
              </div>
            </div>
            <div>
              <label className="block text-xs text-slate-400 mb-1.5">আকার: {size}px</label>
              <input type="range" min={100} max={600} step={50} value={size} onChange={(e) => setSize(Number(e.target.value))} className="w-full accent-sky-500 cursor-pointer" />
            </div>
            <div>
              <label className="block text-xs text-slate-400 mb-1.5">এরর কারেকশন</label>
              <select
                value={overlayType !== "none" ? "H" : errorLevel}
                onChange={(e) => setErrorLevel(e.target.value as ErrorLevel)}
                disabled={overlayType !== "none"}
                className="w-full bg-slate-900/80 border border-slate-600 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:ring-2 focus:ring-sky-500/60 disabled:opacity-50"
              >
                <option value="L">L — লো (7%)</option>
                <option value="M">M — মিডিয়াম (15%)</option>
                <option value="Q">Q — কোয়ার্টার (25%)</option>
                <option value="H">H — হাই (30%)</option>
              </select>
              {overlayType !== "none" && (
                <p className="text-xs text-amber-400 mt-1">লোগোর জন্য স্বয়ংক্রিয়ভাবে H সেট হয়েছে</p>
              )}
            </div>
            <div className="col-span-2">
              <label className="block text-xs text-slate-400 mb-1.5">ফরম্যাট</label>
              <div className="flex gap-3">
                {(["png", "svg"] as OutputFormat[]).map((f) => (
                  <button key={f} onClick={() => setOutputFormat(f)}
                    className={`flex-1 py-2 rounded-xl text-sm font-medium border transition-all ${outputFormat === f ? "bg-sky-500 border-sky-500 text-white shadow-lg shadow-sky-500/25" : "bg-slate-900/80 border-slate-600 text-slate-300 hover:border-sky-500/50"}`}
                  >
                    {f.toUpperCase()}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Overlay / Logo Card */}
        <div className="bg-slate-800/60 backdrop-blur border border-slate-700/50 rounded-2xl p-6 shadow-xl">
          <h2 className="text-sm font-semibold text-slate-300 mb-1 uppercase tracking-wider">লোগো / ওয়াটারমার্ক</h2>
          <p className="text-xs text-slate-500 mb-4">QR কোডের কেন্দ্রে লোগো বা লেখা যোগ করুন (শুধুমাত্র PNG)</p>

          {/* Type selector */}
          <div className="flex gap-2 mb-4">
            {(["none", "image", "text"] as OverlayType[]).map((t) => (
              <button
                key={t}
                onClick={() => setOverlayType(t)}
                className={`flex-1 py-2 rounded-xl text-sm font-medium border transition-all ${overlayType === t ? "bg-violet-500 border-violet-500 text-white shadow-lg shadow-violet-500/20" : "bg-slate-900/80 border-slate-600 text-slate-300 hover:border-violet-500/40"}`}
              >
                {t === "none" ? "নেই" : t === "image" ? "ছবি/লোগো" : "টেক্সট"}
              </button>
            ))}
          </div>

          {/* Image upload */}
          {overlayType === "image" && (
            <div>
              <input ref={logoInputRef} type="file" accept="image/*" onChange={handleLogoUpload} className="hidden" />
              <button
                onClick={() => logoInputRef.current?.click()}
                className="w-full py-3 border-2 border-dashed border-slate-600 hover:border-violet-500/60 rounded-xl text-slate-400 hover:text-violet-300 text-sm transition flex items-center justify-center gap-2"
              >
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                </svg>
                {overlayImageDataUrl ? overlayImageName : "ছবি আপলোড করুন (PNG, JPG, SVG)"}
              </button>
              {overlayImageDataUrl && (
                <div className="mt-3 flex items-center gap-3">
                  <img src={overlayImageDataUrl} alt="preview" className="w-12 h-12 rounded-lg object-contain bg-white border border-slate-600 p-1" />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-white truncate">{overlayImageName}</p>
                    <p className="text-xs text-slate-500">লোগো লোড হয়েছে</p>
                  </div>
                  <button onClick={() => { setOverlayImageDataUrl(""); setOverlayImageName(""); }} className="p-1.5 rounded-lg bg-red-500/20 hover:bg-red-500/40 text-red-400 transition">
                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                    </svg>
                  </button>
                </div>
              )}
            </div>
          )}

          {/* Text overlay */}
          {overlayType === "text" && (
            <div className="space-y-3">
              <div>
                <label className="block text-xs text-slate-400 mb-1.5">ওয়াটারমার্ক টেক্সট</label>
                <input
                  type="text"
                  maxLength={12}
                  value={overlayText}
                  onChange={(e) => setOverlayText(e.target.value)}
                  placeholder="যেমন: LOGO, নাম..."
                  className="w-full bg-slate-900/80 border border-slate-600 rounded-xl px-4 py-2.5 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-violet-500/60 focus:border-violet-500 text-sm transition"
                />
                <p className="text-xs text-slate-500 mt-1">{overlayText.length}/12 অক্ষর</p>
              </div>
              <div>
                <label className="block text-xs text-slate-400 mb-1.5">টেক্সট রঙ</label>
                <div className="flex items-center gap-2 bg-slate-900/80 border border-slate-600 rounded-xl px-3 py-2">
                  <input type="color" value={overlayTextColor} onChange={(e) => setOverlayTextColor(e.target.value)} className="w-8 h-8 rounded-lg cursor-pointer border-0 bg-transparent" />
                  <span className="text-sm text-slate-300 font-mono">{overlayTextColor.toUpperCase()}</span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Caption Card */}
        <div className="bg-slate-800/60 backdrop-blur border border-slate-700/50 rounded-2xl p-6 shadow-xl">
          <h2 className="text-sm font-semibold text-slate-300 mb-1 uppercase tracking-wider flex items-center gap-2">
            <svg className="w-4 h-4 text-sky-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25H12" />
            </svg>
            ক্যাপশন / লেবেল
          </h2>
          <p className="text-xs text-slate-500 mb-4">QR কোডের নিচে একটি লাইন যোগ করুন — ডাউনলোড ও প্রিন্টে দেখাবে (শুধুমাত্র PNG)</p>
          <div className="flex gap-3 items-end">
            <div className="flex-1">
              <label className="block text-xs text-slate-400 mb-1.5">ক্যাপশন টেক্সট</label>
              <input
                type="text"
                maxLength={60}
                value={caption}
                onChange={(e) => setCaption(e.target.value)}
                placeholder="যেমন: স্ক্যান করুন বা সংযুক্ত হন"
                className="w-full bg-slate-900/80 border border-slate-600 rounded-xl px-4 py-2.5 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-sky-500/60 focus:border-sky-500 text-sm transition"
              />
              <p className="text-xs text-slate-500 mt-1">{caption.length}/60 অক্ষর</p>
            </div>
            <div className="flex-shrink-0 pb-6">
              <label className="block text-xs text-slate-400 mb-1.5">রঙ</label>
              <div className="flex items-center gap-2 bg-slate-900/80 border border-slate-600 rounded-xl px-3 py-2">
                <input
                  type="color"
                  value={captionColor}
                  onChange={(e) => setCaptionColor(e.target.value)}
                  className="w-8 h-8 rounded-lg cursor-pointer border-0 bg-transparent"
                />
                <span className="text-sm text-slate-300 font-mono">{captionColor.toUpperCase()}</span>
              </div>
            </div>
          </div>
          {caption.trim() && outputFormat === "svg" && (
            <p className="text-xs text-amber-400 mt-2 flex items-center gap-1.5">
              <svg className="w-3.5 h-3.5 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.538-1.333-3.308 0L3.732 16c-.77 1.333.192 3 1.732 3z" />
              </svg>
              ক্যাপশন PNG ফরম্যাটে কাজ করে। SVG মোডে ক্যাপশন যোগ হবে না।
            </p>
          )}
        </div>

        {/* Generate Button */}
        <button
          onClick={generate}
          disabled={isGenerating || !input.trim()}
          className="w-full py-4 bg-sky-500 hover:bg-sky-400 disabled:opacity-50 disabled:cursor-not-allowed text-white font-semibold rounded-2xl shadow-lg shadow-sky-500/30 transition-all active:scale-95 text-base"
        >
          {isGenerating ? (
            <span className="flex items-center justify-center gap-2">
              <svg className="w-5 h-5 animate-spin" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
              </svg>
              তৈরি হচ্ছে...
            </span>
          ) : "QR কোড তৈরি করুন"}
        </button>

        {/* QR Output */}
        {hasQR && (
          <div className="bg-slate-800/60 backdrop-blur border border-slate-700/50 rounded-2xl p-6 shadow-xl flex flex-col items-center gap-5">
            <div className="rounded-xl overflow-hidden shadow-2xl border border-slate-600/30">
              {outputFormat === "png" && qrDataUrl ? (
                <img src={qrDataUrl} alt="Generated QR Code" style={{ width: size, height: size, display: "block" }} />
              ) : (
                <div
                  style={{ width: size, height: size }}
                  dangerouslySetInnerHTML={{ __html: qrSvg }}
                  className="[&>svg]:w-full [&>svg]:h-full"
                />
              )}
            </div>
            <div className="flex gap-3 w-full">
              <button
                onClick={() => download()}
                className="flex-1 flex items-center justify-center gap-2 py-3 bg-emerald-500 hover:bg-emerald-400 text-white font-semibold rounded-xl shadow-lg shadow-emerald-500/25 transition-all active:scale-95"
              >
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                </svg>
                ডাউনলোড করুন
              </button>
              {outputFormat === "png" && (
                <button
                  onClick={handlePrint}
                  className="px-5 py-3 font-medium rounded-xl transition-all active:scale-95 border bg-slate-700 hover:bg-slate-600 text-slate-200 border-slate-600"
                  title="প্রিন্ট করুন"
                >
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M6.72 13.829c-.24.03-.48.062-.72.096m.72-.096a42.415 42.415 0 0110.56 0m-10.56 0L6.34 18m10.94-4.171c.24.03.48.062.72.096m-.72-.096L17.66 18m0 0l.229 2.523a1.125 1.125 0 01-1.12 1.227H7.231c-.662 0-1.18-.568-1.12-1.227L6.34 18m11.318 0h1.091A2.25 2.25 0 0021 15.75V9.456c0-1.081-.768-2.015-1.837-2.175a48.055 48.055 0 00-1.913-.247M6.34 18H5.25A2.25 2.25 0 013 15.75V9.456c0-1.081.768-2.015 1.837-2.175a48.041 48.041 0 011.913-.247m10.5 0a48.536 48.536 0 00-10.5 0m10.5 0V3.375c0-.621-.504-1.125-1.125-1.125h-8.25c-.621 0-1.125.504-1.125 1.125v3.659M18 10.5h.008v.008H18V10.5zm-3 0h.008v.008H15V10.5z" />
                  </svg>
                </button>
              )}
              <button
                onClick={copyText}
                className={`px-5 py-3 font-medium rounded-xl transition-all active:scale-95 border ${copied ? "bg-sky-500/20 border-sky-500 text-sky-300" : "bg-slate-700 hover:bg-slate-600 text-slate-200 border-slate-600"}`}
                title="টেক্সট কপি করুন"
              >
                {copied ? (
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>
                ) : (
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" /></svg>
                )}
              </button>
            </div>
          </div>
        )}

        {/* History Section */}
        {history.length > 0 && (
          <div className="bg-slate-800/60 backdrop-blur border border-slate-700/50 rounded-2xl shadow-xl overflow-hidden">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-700/50">
              <button
                onClick={() => setShowHistory((v) => !v)}
                className="flex items-center gap-2 text-sm font-semibold text-slate-200 hover:text-white transition"
              >
                <svg className="w-4 h-4 text-sky-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                সাম্প্রতিক ইতিহাস
                <span className="bg-slate-700 text-slate-300 text-xs px-1.5 py-0.5 rounded-full">{history.length}</span>
                <svg className={`w-4 h-4 text-slate-400 transition-transform ${showHistory ? "rotate-180" : ""}`} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
                </svg>
              </button>
              <button onClick={clearAll} className="text-xs text-slate-500 hover:text-red-400 transition flex items-center gap-1">
                <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                </svg>
                সব মুছুন
              </button>
            </div>
            {showHistory && (
              <div className="p-4 space-y-2 max-h-96 overflow-y-auto">
                {history.map((entry) => (
                  <HistoryCard key={entry.id} entry={entry} onReuse={reuseEntry} onDownload={downloadHistoryEntry} onRemove={removeEntry} />
                ))}
              </div>
            )}
          </div>
        )}

        <p className="text-center text-xs text-slate-500 pb-4">
          অফলাইন QR জেনারেটর — প্রিন্ট সাপোর্ট: ব্রাউজার প্রিন্ট
        </p>
      </div>
  );

  if (headless) return inner;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white flex flex-col items-center py-10 px-4">
      <div className="mb-8 text-center">
        <div className="flex items-center justify-center gap-3 mb-2">
          <div className="w-10 h-10 rounded-xl bg-sky-500 flex items-center justify-center shadow-lg shadow-sky-500/30">
            <svg className="w-6 h-6 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <rect x="3" y="3" width="7" height="7" rx="1" />
              <rect x="14" y="3" width="7" height="7" rx="1" />
              <rect x="3" y="14" width="7" height="7" rx="1" />
              <rect x="14" y="14" width="3" height="3" rx="0.5" />
              <rect x="19" y="14" width="2" height="2" rx="0.5" />
              <rect x="14" y="19" width="2" height="2" rx="0.5" />
              <rect x="18" y="18" width="3" height="3" rx="0.5" />
            </svg>
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-white">
            নুরুন্নবী বারকোড জেনারেটর প্রো
          </h1>
        </div>
        <p className="text-slate-400 text-sm">যেকোনো টেক্সট বা URL থেকে QR কোড তৈরি করুন</p>
      </div>
      {inner}
    </div>
  );
}
