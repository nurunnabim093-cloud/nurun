import { useState, useRef, useEffect, useCallback } from "react";
import jsQR from "jsqr";

interface ScanResult {
  text: string;
  scannedAt: number;
}

function isUrl(text: string): boolean {
  try {
    const u = new URL(text);
    return u.protocol === "http:" || u.protocol === "https:";
  } catch {
    return false;
  }
}

export default function QRScanner() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const rafRef = useRef<number>(0);

  const [isActive, setIsActive] = useState(false);
  const [facingMode, setFacingMode] = useState<"environment" | "user">("environment");
  const [permissionState, setPermissionState] = useState<"idle" | "requesting" | "denied" | "granted">("idle");
  const [result, setResult] = useState<ScanResult | null>(null);
  const [copied, setCopied] = useState(false);
  const [scanHistory, setScanHistory] = useState<ScanResult[]>([]);
  const [isFlashing, setIsFlashing] = useState(false);
  const lastScannedRef = useRef<string>("");

  const stopStream = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
    cancelAnimationFrame(rafRef.current);
    setIsActive(false);
  }, []);

  const scanFrame = useCallback(() => {
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (!video || !canvas || video.readyState !== video.HAVE_ENOUGH_DATA) {
      rafRef.current = requestAnimationFrame(scanFrame);
      return;
    }

    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext("2d", { willReadFrequently: true })!;
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const code = jsQR(imageData.data, imageData.width, imageData.height, {
      inversionAttempts: "dontInvert",
    });

    if (code && code.data !== lastScannedRef.current) {
      lastScannedRef.current = code.data;
      const newResult: ScanResult = { text: code.data, scannedAt: Date.now() };
      setResult(newResult);
      setIsFlashing(true);
      setTimeout(() => setIsFlashing(false), 600);
      setScanHistory((prev) => {
        const deduped = prev.filter((r) => r.text !== code.data);
        return [newResult, ...deduped].slice(0, 10);
      });
    }

    rafRef.current = requestAnimationFrame(scanFrame);
  }, []);

  const startCamera = useCallback(async (facing: "environment" | "user") => {
    stopStream();
    setPermissionState("requesting");
    lastScannedRef.current = "";
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: { ideal: facing }, width: { ideal: 1280 }, height: { ideal: 720 } },
      });
      streamRef.current = stream;
      setPermissionState("granted");
      setIsActive(true);
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
        videoRef.current.onloadedmetadata = () => {
          rafRef.current = requestAnimationFrame(scanFrame);
        };
      }
    } catch (e: unknown) {
      const err = e as DOMException;
      if (err.name === "NotAllowedError" || err.name === "PermissionDeniedError") {
        setPermissionState("denied");
      } else {
        setPermissionState("denied");
      }
    }
  }, [stopStream, scanFrame]);

  const toggleCamera = useCallback(async () => {
    const next = facingMode === "environment" ? "user" : "environment";
    setFacingMode(next);
    await startCamera(next);
  }, [facingMode, startCamera]);

  useEffect(() => {
    return () => {
      stopStream();
    };
  }, [stopStream]);

  const copyResult = useCallback(async () => {
    if (!result) return;
    try {
      await navigator.clipboard.writeText(result.text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch { /* ignore */ }
  }, [result]);

  const reset = useCallback(() => {
    setResult(null);
    lastScannedRef.current = "";
  }, []);

  return (
    <div className="w-full max-w-2xl mx-auto space-y-4">
      {/* Camera viewport */}
      <div className="bg-slate-800/60 backdrop-blur border border-slate-700/50 rounded-2xl overflow-hidden shadow-xl">
        {/* Viewfinder */}
        <div className="relative bg-black aspect-video flex items-center justify-center">
          {/* Live video */}
          <video
            ref={videoRef}
            className={`w-full h-full object-cover transition-opacity duration-300 ${isActive ? "opacity-100" : "opacity-0"}`}
            playsInline
            muted
          />

          {/* Flash overlay on scan */}
          {isFlashing && (
            <div className="absolute inset-0 bg-green-400/30 pointer-events-none animate-pulse" />
          )}

          {/* Scan-frame overlay */}
          {isActive && !result && (
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
              <div className="relative w-52 h-52">
                {/* Corner brackets */}
                <span className="absolute top-0 left-0 w-8 h-8 border-t-2 border-l-2 border-sky-400 rounded-tl-lg" />
                <span className="absolute top-0 right-0 w-8 h-8 border-t-2 border-r-2 border-sky-400 rounded-tr-lg" />
                <span className="absolute bottom-0 left-0 w-8 h-8 border-b-2 border-l-2 border-sky-400 rounded-bl-lg" />
                <span className="absolute bottom-0 right-0 w-8 h-8 border-b-2 border-r-2 border-sky-400 rounded-br-lg" />
                {/* Scanning line */}
                <div className="absolute inset-x-2 top-0 h-0.5 bg-sky-400/80 animate-[scan_2s_linear_infinite]" />
              </div>
            </div>
          )}

          {/* Success overlay when result found */}
          {isActive && result && (
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
              <div className="w-52 h-52 relative">
                <span className="absolute top-0 left-0 w-8 h-8 border-t-2 border-l-2 border-emerald-400 rounded-tl-lg" />
                <span className="absolute top-0 right-0 w-8 h-8 border-t-2 border-r-2 border-emerald-400 rounded-tr-lg" />
                <span className="absolute bottom-0 left-0 w-8 h-8 border-b-2 border-l-2 border-emerald-400 rounded-bl-lg" />
                <span className="absolute bottom-0 right-0 w-8 h-8 border-b-2 border-r-2 border-emerald-400 rounded-br-lg" />
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="bg-emerald-500/20 rounded-full p-3">
                    <svg className="w-10 h-10 text-emerald-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Idle / permission states */}
          {!isActive && (
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-4 text-center px-8">
              {permissionState === "denied" ? (
                <>
                  <div className="w-14 h-14 rounded-full bg-red-500/20 flex items-center justify-center">
                    <svg className="w-7 h-7 text-red-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636" />
                    </svg>
                  </div>
                  <div>
                    <p className="text-white font-semibold">ক্যামেরা অ্যাক্সেস অস্বীকৃত</p>
                    <p className="text-slate-400 text-sm mt-1">ব্রাউজারের সেটিংস থেকে ক্যামেরার অনুমতি দিন, তারপর আবার চেষ্টা করুন।</p>
                  </div>
                </>
              ) : permissionState === "requesting" ? (
                <>
                  <svg className="w-10 h-10 text-sky-400 animate-spin" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
                  </svg>
                  <p className="text-slate-300">ক্যামেরা চালু হচ্ছে...</p>
                </>
              ) : (
                <>
                  <div className="w-14 h-14 rounded-full bg-slate-700 flex items-center justify-center">
                    <svg className="w-7 h-7 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
                      <path strokeLinecap="round" strokeLinejoin="round" d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
                    </svg>
                  </div>
                  <p className="text-slate-300 text-sm">ক্যামেরা চালু করে QR কোড স্ক্যান করুন</p>
                </>
              )}
            </div>
          )}

          {/* Camera switch button */}
          {isActive && (
            <button
              onClick={toggleCamera}
              className="absolute top-3 right-3 p-2 rounded-full bg-black/50 hover:bg-black/70 text-white transition backdrop-blur"
              title="ক্যামেরা বদলান"
            >
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
              </svg>
            </button>
          )}

          {/* Hidden canvas for processing */}
          <canvas ref={canvasRef} className="hidden" />
        </div>

        {/* Controls row */}
        <div className="px-5 py-4 flex gap-3">
          {!isActive ? (
            <button
              onClick={() => startCamera(facingMode)}
              disabled={permissionState === "requesting"}
              className="flex-1 flex items-center justify-center gap-2 py-3 bg-sky-500 hover:bg-sky-400 disabled:opacity-50 text-white font-semibold rounded-xl shadow-lg shadow-sky-500/25 transition-all active:scale-95"
            >
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
                <path strokeLinecap="round" strokeLinejoin="round" d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
              </svg>
              ক্যামেরা চালু করুন
            </button>
          ) : (
            <>
              <button
                onClick={stopStream}
                className="flex-1 flex items-center justify-center gap-2 py-3 bg-slate-700 hover:bg-slate-600 text-slate-200 font-semibold rounded-xl border border-slate-600 transition-all active:scale-95"
              >
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <rect x="6" y="6" width="12" height="12" rx="1" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
                বন্ধ করুন
              </button>
              {result && (
                <button
                  onClick={reset}
                  className="px-4 py-3 bg-slate-700 hover:bg-slate-600 text-slate-300 rounded-xl border border-slate-600 transition-all active:scale-95 text-sm"
                  title="আবার স্ক্যান করুন"
                >
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                  </svg>
                </button>
              )}
            </>
          )}
        </div>
      </div>

      {/* Current result card */}
      {result && (
        <div className="bg-slate-800/60 backdrop-blur border border-emerald-500/30 rounded-2xl p-5 shadow-xl">
          <div className="flex items-start gap-3">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/20 flex-shrink-0 flex items-center justify-center mt-0.5">
              <svg className="w-5 h-5 text-emerald-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
              </svg>
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs text-emerald-400 font-semibold uppercase tracking-wider mb-1">স্ক্যান সফল হয়েছে</p>
              <p className="text-white text-sm break-all leading-relaxed">{result.text}</p>
              {isUrl(result.text) && (
                <a
                  href={result.text}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 mt-2 text-xs text-sky-400 hover:text-sky-300 transition"
                >
                  <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                  </svg>
                  লিংক খুলুন
                </a>
              )}
            </div>
          </div>
          <div className="flex gap-2 mt-4">
            <button
              onClick={copyResult}
              className={`flex-1 flex items-center justify-center gap-2 py-2.5 text-sm font-medium rounded-xl transition-all active:scale-95 border ${
                copied
                  ? "bg-sky-500/20 border-sky-500 text-sky-300"
                  : "bg-slate-700 hover:bg-slate-600 text-slate-200 border-slate-600"
              }`}
            >
              {copied ? (
                <>
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                  </svg>
                  কপি হয়েছে
                </>
              ) : (
                <>
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                  </svg>
                  কপি করুন
                </>
              )}
            </button>
          </div>
        </div>
      )}

      {/* Scan history */}
      {scanHistory.length > 0 && (
        <div className="bg-slate-800/60 backdrop-blur border border-slate-700/50 rounded-2xl shadow-xl overflow-hidden">
          <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-700/50">
            <span className="flex items-center gap-2 text-sm font-semibold text-slate-200">
              <svg className="w-4 h-4 text-sky-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              স্ক্যান ইতিহাস
              <span className="bg-slate-700 text-slate-300 text-xs px-1.5 py-0.5 rounded-full">{scanHistory.length}</span>
            </span>
            <button
              onClick={() => setScanHistory([])}
              className="text-xs text-slate-500 hover:text-red-400 transition"
            >
              সব মুছুন
            </button>
          </div>
          <div className="divide-y divide-slate-700/40 max-h-64 overflow-y-auto">
            {scanHistory.map((item) => (
              <div key={item.scannedAt} className="flex items-center gap-3 px-5 py-3 group hover:bg-slate-700/30 transition">
                <div className="w-7 h-7 rounded-lg bg-slate-700 flex-shrink-0 flex items-center justify-center">
                  {isUrl(item.text) ? (
                    <svg className="w-3.5 h-3.5 text-sky-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
                    </svg>
                  ) : (
                    <svg className="w-3.5 h-3.5 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M4 6h16M4 12h16M4 18h7" />
                    </svg>
                  )}
                </div>
                <p className="flex-1 text-sm text-slate-300 truncate">{item.text}</p>
                <div className="flex gap-1.5 opacity-0 group-hover:opacity-100 transition-opacity">
                  {isUrl(item.text) && (
                    <a
                      href={item.text}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="p-1.5 rounded-lg bg-sky-500/20 hover:bg-sky-500/40 text-sky-400 transition"
                      title="খুলুন"
                    >
                      <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                        <path strokeLinecap="round" strokeLinejoin="round" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                      </svg>
                    </a>
                  )}
                  <button
                    onClick={async () => {
                      try { await navigator.clipboard.writeText(item.text); } catch { /* ignore */ }
                    }}
                    className="p-1.5 rounded-lg bg-slate-600/50 hover:bg-slate-600 text-slate-400 hover:text-slate-200 transition"
                    title="কপি"
                  >
                    <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                    </svg>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <p className="text-center text-xs text-slate-500 pb-4">
        ক্যামেরা অ্যাক্সেস শুধুমাত্র স্ক্যানিংয়ের জন্য ব্যবহৃত হয় — কোনো ডেটা সংরক্ষিত হয় না
      </p>

      <style>{`
        @keyframes scan {
          0% { transform: translateY(0); opacity: 1; }
          50% { opacity: 0.6; }
          100% { transform: translateY(192px); opacity: 1; }
        }
      `}</style>
    </div>
  );
}
