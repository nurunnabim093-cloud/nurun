import { useState, useCallback } from "react";
import QRCode from "qrcode";
import JSZip from "jszip";

type ErrorLevel = "L" | "M" | "Q" | "H";

interface BatchItem {
  id: string;
  text: string;
  status: "pending" | "generating" | "done" | "error";
  dataUrl?: string;
}

function slugify(text: string): string {
  return text
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9\u0980-\u09FF]+/g, "_")
    .replace(/^_+|_+$/g, "")
    .slice(0, 40) || "qrcode";
}

export default function BatchGenerator() {
  const [rawInput, setRawInput] = useState("");
  const [fgColor, setFgColor] = useState("#000000");
  const [bgColor, setBgColor] = useState("#ffffff");
  const [size, setSize] = useState(300);
  const [errorLevel, setErrorLevel] = useState<ErrorLevel>("M");

  const [items, setItems] = useState<BatchItem[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isZipping, setIsZipping] = useState(false);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState("");

  const lineCount = rawInput.split("\n").filter((l) => l.trim()).length;

  const parseLines = useCallback((): string[] => {
    return rawInput
      .split("\n")
      .map((l) => l.trim())
      .filter(Boolean);
  }, [rawInput]);

  const generateAll = useCallback(async () => {
    const lines = parseLines();
    if (lines.length === 0) {
      setError("অন্তত একটি আইটেম লিখুন।");
      return;
    }
    if (lines.length > 200) {
      setError("সর্বোচ্চ ২০০টি আইটেম একসাথে তৈরি করা যাবে।");
      return;
    }
    setError("");
    setIsGenerating(true);
    setProgress(0);

    const initial: BatchItem[] = lines.map((text) => ({
      id: crypto.randomUUID(),
      text,
      status: "pending",
    }));
    setItems(initial);

    const results: BatchItem[] = [...initial];

    for (let i = 0; i < lines.length; i++) {
      results[i] = { ...results[i], status: "generating" };
      setItems([...results]);
      try {
        const url = await QRCode.toDataURL(lines[i], {
          width: size,
          margin: 2,
          color: { dark: fgColor, light: bgColor },
          errorCorrectionLevel: errorLevel,
        });
        results[i] = { ...results[i], status: "done", dataUrl: url };
      } catch {
        results[i] = { ...results[i], status: "error" };
      }
      setProgress(Math.round(((i + 1) / lines.length) * 100));
      setItems([...results]);
    }

    setIsGenerating(false);
  }, [parseLines, size, fgColor, bgColor, errorLevel]);

  const downloadAll = useCallback(async () => {
    const done = items.filter((i) => i.status === "done" && i.dataUrl);
    if (done.length === 0) return;
    setIsZipping(true);
    try {
      const zip = new JSZip();
      const folder = zip.folder("qrcodes")!;

      // Track used filenames to avoid collisions
      const usedNames = new Map<string, number>();
      for (const item of done) {
        const base = slugify(item.text);
        const count = usedNames.get(base) ?? 0;
        usedNames.set(base, count + 1);
        const filename = count === 0 ? `${base}.png` : `${base}_${count}.png`;

        // Strip data URL header
        const b64 = item.dataUrl!.split(",")[1];
        folder.file(filename, b64, { base64: true });
      }

      const blob = await zip.generateAsync({ type: "blob" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "qrcodes.zip";
      a.click();
      URL.revokeObjectURL(url);
    } finally {
      setIsZipping(false);
    }
  }, [items]);

  const downloadSingle = useCallback((item: BatchItem) => {
    if (!item.dataUrl) return;
    const a = document.createElement("a");
    a.href = item.dataUrl;
    a.download = `${slugify(item.text)}.png`;
    a.click();
  }, []);

  const doneCount = items.filter((i) => i.status === "done").length;
  const errorCount = items.filter((i) => i.status === "error").length;
  const hasResults = items.length > 0;

  return (
    <div className="w-full max-w-2xl mx-auto space-y-4">
      {/* Input Card */}
      <div className="bg-slate-800/60 backdrop-blur border border-slate-700/50 rounded-2xl p-6 shadow-xl">
        <div className="flex items-start justify-between mb-2">
          <label className="text-sm font-medium text-slate-300">
            আইটেমের তালিকা
          </label>
          <span className={`text-xs px-2 py-0.5 rounded-full font-mono ${lineCount > 200 ? "bg-red-500/20 text-red-400" : "bg-slate-700 text-slate-400"}`}>
            {lineCount} / 200
          </span>
        </div>
        <textarea
          className="w-full bg-slate-900/80 border border-slate-600 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-sky-500/60 focus:border-sky-500 resize-none transition font-mono text-sm"
          rows={8}
          placeholder={"প্রতিটি লাইনে একটি করে আইটেম লিখুন:\nhttps://example.com\nনুরুন্নবী\nhttps://shop.com/item/1\n01XXXXXXXXXX"}
          value={rawInput}
          onChange={(e) => setRawInput(e.target.value)}
        />
        {error && (
          <p className="mt-2 text-sm text-red-400 flex items-center gap-1">
            <svg className="w-4 h-4 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.538-1.333-3.308 0L3.732 16c-.77 1.333.192 3 1.732 3z" />
            </svg>
            {error}
          </p>
        )}
      </div>

      {/* Settings Card */}
      <div className="bg-slate-800/60 backdrop-blur border border-slate-700/50 rounded-2xl p-6 shadow-xl">
        <h2 className="text-sm font-semibold text-slate-300 mb-4 uppercase tracking-wider">সব QR কোডের সেটিংস</h2>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-xs text-slate-400 mb-1.5">QR কোড রঙ</label>
            <div className="flex items-center gap-2 bg-slate-900/80 border border-slate-600 rounded-xl px-3 py-2">
              <input type="color" value={fgColor} onChange={(e) => setFgColor(e.target.value)} className="w-8 h-8 rounded-lg cursor-pointer border-0 bg-transparent" />
              <span className="text-sm text-slate-300 font-mono">{fgColor.toUpperCase()}</span>
            </div>
          </div>
          <div>
            <label className="block text-xs text-slate-400 mb-1.5">ব্যাকগ্রাউন্ড রঙ</label>
            <div className="flex items-center gap-2 bg-slate-900/80 border border-slate-600 rounded-xl px-3 py-2">
              <input type="color" value={bgColor} onChange={(e) => setBgColor(e.target.value)} className="w-8 h-8 rounded-lg cursor-pointer border-0 bg-transparent" />
              <span className="text-sm text-slate-300 font-mono">{bgColor.toUpperCase()}</span>
            </div>
          </div>
          <div>
            <label className="block text-xs text-slate-400 mb-1.5">আকার: {size}px</label>
            <input type="range" min={100} max={600} step={50} value={size} onChange={(e) => setSize(Number(e.target.value))} className="w-full accent-sky-500 cursor-pointer" />
          </div>
          <div>
            <label className="block text-xs text-slate-400 mb-1.5">এরর কারেকশন</label>
            <select
              value={errorLevel}
              onChange={(e) => setErrorLevel(e.target.value as ErrorLevel)}
              className="w-full bg-slate-900/80 border border-slate-600 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:ring-2 focus:ring-sky-500/60"
            >
              <option value="L">L — লো (7%)</option>
              <option value="M">M — মিডিয়াম (15%)</option>
              <option value="Q">Q — কোয়ার্টার (25%)</option>
              <option value="H">H — হাই (30%)</option>
            </select>
          </div>
        </div>
      </div>

      {/* Generate Button */}
      <button
        onClick={generateAll}
        disabled={isGenerating || lineCount === 0 || lineCount > 200}
        className="w-full py-4 bg-sky-500 hover:bg-sky-400 disabled:opacity-50 disabled:cursor-not-allowed text-white font-semibold rounded-2xl shadow-lg shadow-sky-500/30 transition-all active:scale-95 text-base"
      >
        {isGenerating ? (
          <span className="flex items-center justify-center gap-2">
            <svg className="w-5 h-5 animate-spin" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
            </svg>
            তৈরি হচ্ছে... ({progress}%)
          </span>
        ) : (
          `${lineCount > 0 ? lineCount + "টি " : ""}QR কোড তৈরি করুন`
        )}
      </button>

      {/* Progress bar */}
      {isGenerating && (
        <div className="w-full bg-slate-700 rounded-full h-2 overflow-hidden">
          <div
            className="bg-sky-500 h-2 rounded-full transition-all duration-200"
            style={{ width: `${progress}%` }}
          />
        </div>
      )}

      {/* Results */}
      {hasResults && !isGenerating && (
        <div className="bg-slate-800/60 backdrop-blur border border-slate-700/50 rounded-2xl shadow-xl overflow-hidden">
          {/* Results header */}
          <div className="flex items-center justify-between px-6 py-4 border-b border-slate-700/50">
            <div className="flex items-center gap-3">
              <span className="flex items-center gap-1.5 text-sm text-emerald-400 font-medium">
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                </svg>
                {doneCount} সফল
              </span>
              {errorCount > 0 && (
                <span className="flex items-center gap-1.5 text-sm text-red-400 font-medium">
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                  </svg>
                  {errorCount} ব্যর্থ
                </span>
              )}
            </div>
            <button
              onClick={downloadAll}
              disabled={isZipping || doneCount === 0}
              className="flex items-center gap-2 px-4 py-2 bg-emerald-500 hover:bg-emerald-400 disabled:opacity-50 disabled:cursor-not-allowed text-white text-sm font-semibold rounded-xl shadow-lg shadow-emerald-500/25 transition-all active:scale-95"
            >
              {isZipping ? (
                <>
                  <svg className="w-4 h-4 animate-spin" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
                  </svg>
                  ZIP তৈরি হচ্ছে...
                </>
              ) : (
                <>
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                  </svg>
                  সব ZIP করুন
                </>
              )}
            </button>
          </div>

          {/* Grid of QR thumbnails */}
          <div className="p-4 grid grid-cols-2 sm:grid-cols-3 gap-3 max-h-[520px] overflow-y-auto">
            {items.map((item) => (
              <div
                key={item.id}
                className={`relative rounded-xl border overflow-hidden flex flex-col group ${
                  item.status === "done"
                    ? "border-slate-700/50 bg-slate-900/60"
                    : item.status === "error"
                    ? "border-red-500/30 bg-red-900/10"
                    : "border-slate-700/30 bg-slate-900/30"
                }`}
              >
                {/* Thumbnail */}
                <div className="aspect-square flex items-center justify-center bg-white p-2">
                  {item.status === "done" && item.dataUrl ? (
                    <img src={item.dataUrl} alt={item.text} className="w-full h-full object-contain" />
                  ) : item.status === "generating" ? (
                    <svg className="w-8 h-8 text-sky-400 animate-spin" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
                    </svg>
                  ) : item.status === "error" ? (
                    <svg className="w-8 h-8 text-red-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.538-1.333-3.308 0L3.732 16c-.77 1.333.192 3 1.732 3z" />
                    </svg>
                  ) : (
                    <div className="w-8 h-8 rounded-full border-2 border-dashed border-slate-300" />
                  )}
                </div>

                {/* Label */}
                <div className="px-2 py-1.5 flex items-center justify-between gap-1 min-w-0">
                  <p className="text-xs text-slate-300 truncate flex-1">{item.text}</p>
                  {item.status === "done" && (
                    <button
                      onClick={() => downloadSingle(item)}
                      className="flex-shrink-0 opacity-0 group-hover:opacity-100 p-1 rounded bg-emerald-500/20 hover:bg-emerald-500/40 text-emerald-400 transition"
                      title="ডাউনলোড করুন"
                    >
                      <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                        <path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                      </svg>
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <p className="text-center text-xs text-slate-500 pb-4">
        অফলাইন QR জেনারেটর — প্রিন্ট সাপোর্ট: ব্রাউজার প্রিন্ট
      </p>
    </div>
  );
}
