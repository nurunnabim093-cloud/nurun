import { useState, useCallback } from "react";

export interface HistoryEntry {
  id: string;
  text: string;
  dataUrl: string;
  fgColor: string;
  bgColor: string;
  size: number;
  errorLevel: string;
  format: "png" | "svg";
  createdAt: number;
}

const STORAGE_KEY = "qr_history";
const MAX_ENTRIES = 20;

function loadHistory(): HistoryEntry[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    return JSON.parse(raw) as HistoryEntry[];
  } catch {
    return [];
  }
}

function saveHistory(entries: HistoryEntry[]) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(entries));
  } catch {
    // storage full or unavailable — silently skip
  }
}

export function useQRHistory() {
  const [history, setHistory] = useState<HistoryEntry[]>(loadHistory);

  const addEntry = useCallback((entry: Omit<HistoryEntry, "id" | "createdAt">) => {
    setHistory((prev) => {
      const deduped = prev.filter((e) => e.text !== entry.text);
      const next: HistoryEntry[] = [
        { ...entry, id: crypto.randomUUID(), createdAt: Date.now() },
        ...deduped,
      ].slice(0, MAX_ENTRIES);
      saveHistory(next);
      return next;
    });
  }, []);

  const removeEntry = useCallback((id: string) => {
    setHistory((prev) => {
      const next = prev.filter((e) => e.id !== id);
      saveHistory(next);
      return next;
    });
  }, []);

  const clearAll = useCallback(() => {
    localStorage.removeItem(STORAGE_KEY);
    setHistory([]);
  }, []);

  return { history, addEntry, removeEntry, clearAll };
}
