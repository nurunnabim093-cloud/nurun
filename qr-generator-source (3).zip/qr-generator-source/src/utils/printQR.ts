export function printQR(options: {
  dataUrl: string;
  label: string;
  sublabel?: string;
  size?: number;
}) {
  const { dataUrl, label, sublabel, size = 300 } = options;

  const printSize = Math.min(size, 400);

  const html = `<!DOCTYPE html>
<html lang="bn">
<head>
  <meta charset="UTF-8" />
  <title>QR প্রিন্ট — ${label}</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    @page { size: A4; margin: 20mm; }
    body {
      font-family: 'Segoe UI', Arial, sans-serif;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      min-height: 100vh;
      background: #fff;
      color: #111;
      padding: 24px;
    }
    .card {
      display: inline-flex;
      flex-direction: column;
      align-items: center;
      gap: 16px;
      border: 2px solid #e5e7eb;
      border-radius: 16px;
      padding: 32px 40px;
      background: #fff;
      box-shadow: 0 4px 24px rgba(0,0,0,0.08);
      page-break-inside: avoid;
    }
    .qr-img {
      display: block;
      width: ${printSize}px;
      height: ${printSize}px;
      border-radius: 8px;
    }
    .divider {
      width: 100%;
      height: 1px;
      background: #e5e7eb;
      margin: 4px 0;
    }
    .label {
      font-size: 18px;
      font-weight: 700;
      color: #111;
      text-align: center;
      max-width: ${printSize}px;
      word-break: break-all;
    }
    .sublabel {
      font-size: 13px;
      color: #6b7280;
      text-align: center;
      max-width: ${printSize}px;
    }
    .footer {
      margin-top: 32px;
      font-size: 11px;
      color: #d1d5db;
      letter-spacing: 0.05em;
    }
    @media print {
      body { padding: 0; min-height: auto; }
      .card { box-shadow: none; border-color: #ccc; }
    }
  </style>
</head>
<body>
  <div class="card">
    <img class="qr-img" src="${dataUrl}" alt="QR Code" />
    <div class="divider"></div>
    <div class="label">${escapeHtml(label)}</div>
    ${sublabel ? `<div class="sublabel">${escapeHtml(sublabel)}</div>` : ""}
  </div>
  <div class="footer">নুরুন্নবী বারকোড জেনারেটর প্রো</div>
  <script>
    window.onload = function() {
      window.focus();
      window.print();
      window.onafterprint = function() { window.close(); };
      setTimeout(function() { window.close(); }, 3000);
    };
  </script>
</body>
</html>`;

  const w = window.open("", "_blank", "width=600,height=700");
  if (!w) return;
  w.document.write(html);
  w.document.close();
}

function escapeHtml(s: string): string {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}
